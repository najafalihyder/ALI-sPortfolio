import { pgTable, text, varchar, timestamp, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table - Firebase auth users with profile data
export const users = pgTable("users", {
  id: varchar("id", { length: 128 }).primaryKey(), // Firebase UID
  email: text("email").notNull().unique(),
  displayName: text("display_name").notNull(),
  photoURL: text("photo_url"),
  voiceConsentGranted: boolean("voice_consent_granted").default(false),
  voiceConsentTimestamp: timestamp("voice_consent_timestamp"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Documents uploaded by users (PDF or URL)
export const documents = pgTable("documents", {
  id: varchar("id", { length: 36 }).primaryKey(),
  userId: varchar("user_id", { length: 128 }).notNull().references(() => users.id),
  title: text("title").notNull(),
  type: text("type").notNull(), // 'pdf' or 'url'
  originalUrl: text("original_url"), // For URL-based documents
  extractedText: text("extracted_text").notNull(),
  uploadedAt: timestamp("uploaded_at").defaultNow().notNull(),
});

// AI-generated lessons from documents
export const lessons = pgTable("lessons", {
  id: varchar("id", { length: 36 }).primaryKey(),
  documentId: varchar("document_id", { length: 36 }).notNull().references(() => documents.id),
  userId: varchar("user_id", { length: 128 }).notNull().references(() => users.id),
  title: text("title").notNull(),
  content: jsonb("content").notNull(), // Structured lesson with segments, analogies, examples
  transcript: text("transcript").notNull(), // Full text for TTS
  duration: integer("duration").notNull(), // Estimated minutes
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Quizzes generated for lessons
export const quizzes = pgTable("quizzes", {
  id: varchar("id", { length: 36 }).primaryKey(),
  lessonId: varchar("lesson_id", { length: 36 }).notNull().references(() => lessons.id),
  questions: jsonb("questions").notNull(), // Array of question objects
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// User quiz attempts and scores
export const quizAttempts = pgTable("quiz_attempts", {
  id: varchar("id", { length: 36 }).primaryKey(),
  quizId: varchar("quiz_id", { length: 36 }).notNull().references(() => quizzes.id),
  userId: varchar("user_id", { length: 128 }).notNull().references(() => users.id),
  answers: jsonb("answers").notNull(), // User's answers
  score: integer("score").notNull(), // Percentage
  completedAt: timestamp("completed_at").defaultNow().notNull(),
});

// Learning competitions
export const competitions = pgTable("competitions", {
  id: varchar("id", { length: 36 }).primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  topic: text("topic").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  status: text("status").notNull().default('upcoming'), // 'upcoming', 'active', 'completed'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Competition participants
export const competitionParticipants = pgTable("competition_participants", {
  id: varchar("id", { length: 36 }).primaryKey(),
  competitionId: varchar("competition_id", { length: 36 }).notNull().references(() => competitions.id),
  userId: varchar("user_id", { length: 128 }).notNull().references(() => users.id),
  score: integer("score").default(0).notNull(),
  rank: integer("rank"),
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
});

// Content flagging/reporting
export const contentReports = pgTable("content_reports", {
  id: varchar("id", { length: 36 }).primaryKey(),
  userId: varchar("user_id", { length: 128 }).notNull().references(() => users.id),
  lessonId: varchar("lesson_id", { length: 36 }).references(() => lessons.id),
  reportType: text("report_type").notNull(), // 'incorrect', 'hallucination', 'inappropriate'
  description: text("description").notNull(),
  segmentReference: text("segment_reference"), // Which part of the lesson
  status: text("status").notNull().default('pending'), // 'pending', 'reviewed', 'resolved'
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  reviewedAt: timestamp("reviewed_at"),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  id: true,
  email: true,
  displayName: true,
  photoURL: true,
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  uploadedAt: true,
});

export const insertLessonSchema = createInsertSchema(lessons).omit({
  id: true,
  createdAt: true,
});

export const insertQuizSchema = createInsertSchema(quizzes).omit({
  id: true,
  createdAt: true,
});

export const insertQuizAttemptSchema = createInsertSchema(quizAttempts).omit({
  id: true,
  completedAt: true,
});

export const insertCompetitionSchema = createInsertSchema(competitions).omit({
  id: true,
  createdAt: true,
});

export const insertCompetitionParticipantSchema = createInsertSchema(competitionParticipants).omit({
  id: true,
  joinedAt: true,
});

export const insertContentReportSchema = createInsertSchema(contentReports).omit({
  id: true,
  createdAt: true,
  reviewedAt: true,
});

// TypeScript types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;

export type Lesson = typeof lessons.$inferSelect;
export type InsertLesson = z.infer<typeof insertLessonSchema>;

export type Quiz = typeof quizzes.$inferSelect;
export type InsertQuiz = z.infer<typeof insertQuizSchema>;

export type QuizAttempt = typeof quizAttempts.$inferSelect;
export type InsertQuizAttempt = z.infer<typeof insertQuizAttemptSchema>;

export type Competition = typeof competitions.$inferSelect;
export type InsertCompetition = z.infer<typeof insertCompetitionSchema>;

export type CompetitionParticipant = typeof competitionParticipants.$inferSelect;
export type InsertCompetitionParticipant = z.infer<typeof insertCompetitionParticipantSchema>;

export type ContentReport = typeof contentReports.$inferSelect;
export type InsertContentReport = z.infer<typeof insertContentReportSchema>;

// Lesson content structure types
export interface LessonSegment {
  id: string;
  text: string;
  type: 'introduction' | 'explanation' | 'analogy' | 'example' | 'summary';
  sourceReference?: string; // Citation to original document
}

export interface LessonContent {
  segments: LessonSegment[];
  keyPoints: string[];
  analogies: string[];
  examples: string[];
}

// Quiz question types
export interface QuizQuestion {
  id: string;
  type: 'multiple-choice' | 'short-answer';
  question: string;
  options?: string[]; // For MCQ
  correctAnswer: string;
  explanation: string;
}
