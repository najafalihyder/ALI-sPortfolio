import { storage } from "./storage";

export async function seedDatabase() {
  try {
    console.log("Seeding database with sample competitions...");

    // Create sample competitions
    const competitions = [
      {
        title: "JavaScript Fundamentals Challenge",
        description: "Master the core concepts of JavaScript including variables, functions, and async programming",
        topic: "JavaScript Programming",
        startDate: new Date(),
        endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
        status: "active",
      },
      {
        title: "Machine Learning Basics",
        description: "Learn the fundamentals of ML algorithms, neural networks, and data preprocessing",
        topic: "Machine Learning",
        startDate: new Date(),
        endDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000), // 45 days from now
        status: "active",
      },
      {
        title: "Web Development Sprint",
        description: "Build full-stack web applications using modern frameworks and best practices",
        topic: "Web Development",
        startDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // starts in 7 days
        endDate: new Date(Date.now() + 37 * 24 * 60 * 60 * 1000),
        status: "upcoming",
      },
    ];

    for (const comp of competitions) {
      await storage.createCompetition(comp);
    }

    console.log("✓ Database seeded successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}
