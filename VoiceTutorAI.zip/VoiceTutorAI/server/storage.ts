import {
  type User,
  type InsertUser,
  type Document,
  type InsertDocument,
  type Lesson,
  type InsertLesson,
  type Quiz,
  type InsertQuiz,
  type QuizAttempt,
  type InsertQuizAttempt,
  type Competition,
  type InsertCompetition,
  type CompetitionParticipant,
  type InsertCompetitionParticipant,
  type ContentReport,
  type InsertContentReport,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserVoiceConsent(id: string, granted: boolean): Promise<User | undefined>;

  // Document operations
  getDocument(id: string): Promise<Document | undefined>;
  getDocumentsByUser(userId: string): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;

  // Lesson operations
  getLesson(id: string): Promise<Lesson | undefined>;
  getLessonsByUser(userId: string): Promise<Lesson[]>;
  getLessonsByDocument(documentId: string): Promise<Lesson[]>;
  createLesson(lesson: InsertLesson): Promise<Lesson>;

  // Quiz operations
  getQuiz(id: string): Promise<Quiz | undefined>;
  getQuizByLesson(lessonId: string): Promise<Quiz | undefined>;
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;

  // Quiz attempt operations
  getQuizAttemptsByUser(userId: string): Promise<QuizAttempt[]>;
  createQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt>;

  // Competition operations
  getCompetition(id: string): Promise<Competition | undefined>;
  getActiveCompetitions(): Promise<Competition[]>;
  getAllCompetitions(): Promise<Competition[]>;
  createCompetition(competition: InsertCompetition): Promise<Competition>;
  updateCompetitionStatus(id: string, status: string): Promise<Competition | undefined>;

  // Competition participant operations
  getCompetitionParticipants(competitionId: string): Promise<CompetitionParticipant[]>;
  getUserCompetitions(userId: string): Promise<CompetitionParticipant[]>;
  joinCompetition(participant: InsertCompetitionParticipant): Promise<CompetitionParticipant>;
  updateParticipantScore(id: string, score: number): Promise<CompetitionParticipant | undefined>;

  // Content report operations
  getContentReport(id: string): Promise<ContentReport | undefined>;
  getPendingReports(): Promise<ContentReport[]>;
  getAllReports(): Promise<ContentReport[]>;
  createContentReport(report: InsertContentReport): Promise<ContentReport>;
  updateReportStatus(id: string, status: string, adminNotes?: string): Promise<ContentReport | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private documents: Map<string, Document>;
  private lessons: Map<string, Lesson>;
  private quizzes: Map<string, Quiz>;
  private quizAttempts: Map<string, QuizAttempt>;
  private competitions: Map<string, Competition>;
  private competitionParticipants: Map<string, CompetitionParticipant>;
  private contentReports: Map<string, ContentReport>;

  constructor() {
    this.users = new Map();
    this.documents = new Map();
    this.lessons = new Map();
    this.quizzes = new Map();
    this.quizAttempts = new Map();
    this.competitions = new Map();
    this.competitionParticipants = new Map();
    this.contentReports = new Map();
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find((user) => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      ...insertUser,
      photoURL: insertUser.photoURL || null,
      voiceConsentGranted: false,
      voiceConsentTimestamp: null,
      createdAt: new Date(),
    };
    this.users.set(user.id, user);
    return user;
  }

  async updateUserVoiceConsent(id: string, granted: boolean): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    user.voiceConsentGranted = granted;
    user.voiceConsentTimestamp = new Date();
    this.users.set(id, user);
    return user;
  }

  // Document operations
  async getDocument(id: string): Promise<Document | undefined> {
    return this.documents.get(id);
  }

  async getDocumentsByUser(userId: string): Promise<Document[]> {
    return Array.from(this.documents.values())
      .filter((doc) => doc.userId === userId)
      .sort((a, b) => b.uploadedAt.getTime() - a.uploadedAt.getTime());
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = randomUUID();
    const document: Document = {
      ...insertDocument,
      id,
      originalUrl: insertDocument.originalUrl || null,
      uploadedAt: new Date(),
    };
    this.documents.set(id, document);
    return document;
  }

  // Lesson operations
  async getLesson(id: string): Promise<Lesson | undefined> {
    return this.lessons.get(id);
  }

  async getLessonsByUser(userId: string): Promise<Lesson[]> {
    return Array.from(this.lessons.values())
      .filter((lesson) => lesson.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getLessonsByDocument(documentId: string): Promise<Lesson[]> {
    return Array.from(this.lessons.values())
      .filter((lesson) => lesson.documentId === documentId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createLesson(insertLesson: InsertLesson): Promise<Lesson> {
    const id = randomUUID();
    const lesson: Lesson = {
      ...insertLesson,
      id,
      createdAt: new Date(),
    };
    this.lessons.set(id, lesson);
    return lesson;
  }

  // Quiz operations
  async getQuiz(id: string): Promise<Quiz | undefined> {
    return this.quizzes.get(id);
  }

  async getQuizByLesson(lessonId: string): Promise<Quiz | undefined> {
    return Array.from(this.quizzes.values()).find((quiz) => quiz.lessonId === lessonId);
  }

  async createQuiz(insertQuiz: InsertQuiz): Promise<Quiz> {
    const id = randomUUID();
    const quiz: Quiz = {
      ...insertQuiz,
      id,
      createdAt: new Date(),
    };
    this.quizzes.set(id, quiz);
    return quiz;
  }

  // Quiz attempt operations
  async getQuizAttemptsByUser(userId: string): Promise<QuizAttempt[]> {
    return Array.from(this.quizAttempts.values())
      .filter((attempt) => attempt.userId === userId)
      .sort((a, b) => b.completedAt.getTime() - a.completedAt.getTime());
  }

  async createQuizAttempt(insertAttempt: InsertQuizAttempt): Promise<QuizAttempt> {
    const id = randomUUID();
    const attempt: QuizAttempt = {
      ...insertAttempt,
      id,
      completedAt: new Date(),
    };
    this.quizAttempts.set(id, attempt);
    return attempt;
  }

  // Competition operations
  async getCompetition(id: string): Promise<Competition | undefined> {
    return this.competitions.get(id);
  }

  async getActiveCompetitions(): Promise<Competition[]> {
    const now = new Date();
    return Array.from(this.competitions.values())
      .filter((comp) => comp.status === 'active' || (comp.startDate <= now && comp.endDate >= now))
      .sort((a, b) => a.startDate.getTime() - b.startDate.getTime());
  }

  async getAllCompetitions(): Promise<Competition[]> {
    return Array.from(this.competitions.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createCompetition(insertCompetition: InsertCompetition): Promise<Competition> {
    const id = randomUUID();
    const competition: Competition = {
      ...insertCompetition,
      id,
      createdAt: new Date(),
    };
    this.competitions.set(id, competition);
    return competition;
  }

  async updateCompetitionStatus(id: string, status: string): Promise<Competition | undefined> {
    const competition = this.competitions.get(id);
    if (!competition) return undefined;
    competition.status = status;
    this.competitions.set(id, competition);
    return competition;
  }

  // Competition participant operations
  async getCompetitionParticipants(competitionId: string): Promise<CompetitionParticipant[]> {
    return Array.from(this.competitionParticipants.values())
      .filter((p) => p.competitionId === competitionId)
      .sort((a, b) => (b.score || 0) - (a.score || 0));
  }

  async getUserCompetitions(userId: string): Promise<CompetitionParticipant[]> {
    return Array.from(this.competitionParticipants.values())
      .filter((p) => p.userId === userId)
      .sort((a, b) => b.joinedAt.getTime() - a.joinedAt.getTime());
  }

  async joinCompetition(insertParticipant: InsertCompetitionParticipant): Promise<CompetitionParticipant> {
    const id = randomUUID();
    const participant: CompetitionParticipant = {
      ...insertParticipant,
      id,
      score: 0,
      rank: null,
      joinedAt: new Date(),
    };
    this.competitionParticipants.set(id, participant);
    return participant;
  }

  async updateParticipantScore(id: string, score: number): Promise<CompetitionParticipant | undefined> {
    const participant = this.competitionParticipants.get(id);
    if (!participant) return undefined;
    participant.score = score;
    this.competitionParticipants.set(id, participant);
    return participant;
  }

  // Content report operations
  async getContentReport(id: string): Promise<ContentReport | undefined> {
    return this.contentReports.get(id);
  }

  async getPendingReports(): Promise<ContentReport[]> {
    return Array.from(this.contentReports.values())
      .filter((report) => report.status === 'pending')
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getAllReports(): Promise<ContentReport[]> {
    return Array.from(this.contentReports.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createContentReport(insertReport: InsertContentReport): Promise<ContentReport> {
    const id = randomUUID();
    const report: ContentReport = {
      ...insertReport,
      id,
      lessonId: insertReport.lessonId || null,
      segmentReference: insertReport.segmentReference || null,
      adminNotes: null,
      createdAt: new Date(),
      reviewedAt: null,
    };
    this.contentReports.set(id, report);
    return report;
  }

  async updateReportStatus(id: string, status: string, adminNotes?: string): Promise<ContentReport | undefined> {
    const report = this.contentReports.get(id);
    if (!report) return undefined;
    report.status = status;
    if (adminNotes) report.adminNotes = adminNotes;
    report.reviewedAt = new Date();
    this.contentReports.set(id, report);
    return report;
  }
}

export const storage = new MemStorage();
