import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import { z } from "zod";
import { PDFParse } from "pdf-parse";
import { load } from "cheerio";
import fetch from "node-fetch";

// Set up multer for file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // ========== AUTH ROUTES ==========
  
  // Sync user from Firebase to our database
  app.post("/api/auth/sync", async (req, res) => {
    try {
      const { id, email, displayName, photoURL } = req.body;
      
      // Check if user exists
      let user = await storage.getUser(id);
      
      if (!user) {
        // Create new user
        user = await storage.createUser({
          id,
          email,
          displayName,
          photoURL: photoURL || undefined,
        });
      }
      
      res.json(user);
    } catch (error: any) {
      console.error("Auth sync error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // ========== DOCUMENT ROUTES ==========
  
  // Upload PDF document
  app.post("/api/documents/upload", upload.single("file"), async (req, res) => {
    try {
      const file = req.file;
      const userId = req.body.userId;

      if (!file || !userId) {
        return res.status(400).json({ error: "Missing file or userId" });
      }

      // Extract text from PDF
      let extractedText: string;
      const parser = new PDFParse({ data: file.buffer });
      try {
        const pdfData = await parser.getText();
        extractedText = pdfData.text.trim();
        
        if (!extractedText || extractedText.length < 50) {
          return res.status(400).json({ 
            error: "Could not extract sufficient text from PDF. Please ensure the PDF contains readable text." 
          });
        }
      } catch (pdfError: any) {
        console.error("PDF extraction error:", pdfError);
        return res.status(400).json({ 
          error: "Failed to process PDF file. Please ensure it's a valid PDF with text content." 
        });
      } finally {
        await parser.destroy();
      }
      
      // Create document
      const document = await storage.createDocument({
        userId,
        title: file.originalname.replace('.pdf', ''),
        type: 'pdf',
        extractedText,
      });

      // Generate lesson immediately
      const lesson = await generateLesson(document, userId);
      
      res.json({ document, lessonId: lesson.id });
    } catch (error: any) {
      console.error("Upload error:", error);
      res.status(500).json({ error: error.message || "Failed to upload document" });
    }
  });

  // Process URL
  app.post("/api/documents/url", async (req, res) => {
    try {
      const { url, userId } = req.body;

      if (!url || !userId) {
        return res.status(400).json({ error: "Missing url or userId" });
      }

      // Validate URL
      let parsedUrl;
      try {
        parsedUrl = new URL(url);
      } catch {
        return res.status(400).json({ error: "Invalid URL format" });
      }

      // Fetch and extract URL content
      let extractedText: string;
      let title: string;
      
      try {
        const response = await fetch(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (compatible; LearnVoiceBot/1.0)',
          },
        });

        if (!response.ok) {
          return res.status(400).json({ 
            error: `Failed to fetch URL: ${response.statusText}` 
          });
        }

        const html = await response.text();
        const $ = load(html);

        // Remove script and style elements
        $('script, style, nav, header, footer, aside').remove();

        // Try to get title
        title = $('title').text().trim() || 
                $('h1').first().text().trim() || 
                parsedUrl.hostname.replace('www.', '');

        // Extract main content - prioritize article/main content areas
        const contentSelectors = [
          'article',
          'main',
          '[role="main"]',
          '.post-content',
          '.article-content',
          '.entry-content',
          'body'
        ];

        let mainContent = '';
        for (const selector of contentSelectors) {
          const content = $(selector).text();
          if (content && content.length > mainContent.length) {
            mainContent = content;
          }
        }

        // Clean up whitespace
        extractedText = mainContent
          .replace(/\s+/g, ' ')
          .trim();

        if (!extractedText || extractedText.length < 100) {
          return res.status(400).json({ 
            error: "Could not extract sufficient content from URL. Please try a different article or webpage." 
          });
        }

        // Limit to reasonable size (50,000 characters)
        if (extractedText.length > 50000) {
          extractedText = extractedText.slice(0, 50000) + "...";
        }

      } catch (fetchError: any) {
        console.error("URL fetch error:", fetchError);
        return res.status(400).json({ 
          error: "Failed to fetch or parse URL content. Please ensure the URL is accessible." 
        });
      }
      
      // Create document
      const document = await storage.createDocument({
        userId,
        title,
        type: 'url',
        originalUrl: url,
        extractedText,
      });

      // Generate lesson immediately
      const lesson = await generateLesson(document, userId);
      
      res.json({ document, lessonId: lesson.id });
    } catch (error: any) {
      console.error("URL processing error:", error);
      res.status(500).json({ error: error.message || "Failed to process URL" });
    }
  });

  // Get user's documents
  app.get("/api/documents/user/:userId", async (req, res) => {
    try {
      const documents = await storage.getDocumentsByUser(req.params.userId);
      res.json(documents);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ========== LESSON ROUTES ==========
  
  // Get lesson by ID
  app.get("/api/lessons/:id", async (req, res) => {
    try {
      const lesson = await storage.getLesson(req.params.id);
      if (!lesson) {
        return res.status(404).json({ error: "Lesson not found" });
      }
      res.json(lesson);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get user's lessons
  app.get("/api/lessons/user/:userId", async (req, res) => {
    try {
      const lessons = await storage.getLessonsByUser(req.params.userId);
      res.json(lessons);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ========== QUIZ ROUTES ==========
  
  // Get quiz by ID
  app.get("/api/quizzes/:id", async (req, res) => {
    try {
      const quiz = await storage.getQuiz(req.params.id);
      if (!quiz) {
        return res.status(404).json({ error: "Quiz not found" });
      }
      res.json(quiz);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get quiz by lesson ID
  app.get("/api/quizzes/lesson/:lessonId", async (req, res) => {
    try {
      const quiz = await storage.getQuizByLesson(req.params.lessonId);
      res.json(quiz);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Submit quiz
  app.post("/api/quizzes/submit", async (req, res) => {
    try {
      const { quizId, userId, answers } = req.body;
      
      const quiz = await storage.getQuiz(quizId);
      if (!quiz) {
        return res.status(404).json({ error: "Quiz not found" });
      }

      // Calculate score with fuzzy matching
      const questions = quiz.questions as any[];
      let correct = 0;
      
      for (let i = 0; i < questions.length; i++) {
        const userAnswer = (answers[i] || "").toLowerCase().trim();
        const correctAnswer = questions[i].correctAnswer.toLowerCase().trim();
        
        // Simple fuzzy matching: 70% similarity threshold
        const similarity = calculateSimilarity(userAnswer, correctAnswer);
        if (similarity >= 0.7 || userAnswer === correctAnswer) {
          correct++;
        }
      }

      const score = Math.round((correct / questions.length) * 100);

      // Save attempt
      await storage.createQuizAttempt({
        quizId,
        userId,
        answers,
        score,
      });

      res.json({ score, correct, total: questions.length });
    } catch (error: any) {
      console.error("Quiz submission error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // ========== COMPETITION ROUTES ==========
  
  // Get active competitions
  app.get("/api/competitions/active", async (req, res) => {
    try {
      const competitions = await storage.getActiveCompetitions();
      res.json(competitions);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get user's competitions
  app.get("/api/competitions/user/:userId", async (req, res) => {
    try {
      const participations = await storage.getUserCompetitions(req.params.userId);
      res.json(participations);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Join competition
  app.post("/api/competitions/join", async (req, res) => {
    try {
      const { competitionId, userId } = req.body;
      
      const participation = await storage.joinCompetition({
        competitionId,
        userId,
      });
      
      res.json(participation);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ========== VOICE CONSENT ROUTES ==========
  
  // Update voice consent
  app.post("/api/voice/consent", async (req, res) => {
    try {
      const { userId, granted } = req.body;
      
      const user = await storage.updateUserVoiceConsent(userId, granted);
      
      res.json(user);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ========== CONTENT REPORT ROUTES ==========
  
  // Create content report
  app.post("/api/reports", async (req, res) => {
    try {
      const report = await storage.createContentReport(req.body);
      res.json(report);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get pending reports
  app.get("/api/reports/pending", async (req, res) => {
    try {
      const reports = await storage.getPendingReports();
      res.json(reports);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Review report
  app.post("/api/reports/:id/review", async (req, res) => {
    try {
      const { status, adminNotes } = req.body;
      
      const report = await storage.updateReportStatus(
        req.params.id,
        status,
        adminNotes
      );
      
      res.json(report);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ========== ADMIN ROUTES ==========
  
  // Get admin stats
  app.get("/api/admin/stats", async (req, res) => {
    try {
      const stats = {
        totalUsers: 0, // TODO: Implement actual counting
        totalLessons: 0,
        totalCompetitions: 0,
        pendingReports: (await storage.getPendingReports()).length,
      };
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ========== HELPER FUNCTIONS ==========
  
  async function generateLesson(document: any, userId: string) {
    try {
      // Call OpenRouter API to generate lesson
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "anthropic/claude-3.5-sonnet",
          messages: [
            {
              role: "system",
              content: `You are Mate, a friendly and pedagogically skilled AI teacher. Your goal is to create engaging, high-quality lessons that help students truly understand concepts through:
1. Clear, step-by-step explanations
2. Relatable analogies that connect new concepts to familiar ideas
3. Concrete real-world examples
4. Structured content with clear learning objectives

Format your response as JSON with this structure:
{
  "title": "Lesson title",
  "segments": [
    {"id": "1", "type": "introduction", "text": "Introduction text"},
    {"id": "2", "type": "explanation", "text": "Main explanation"},
    {"id": "3", "type": "analogy", "text": "Relatable analogy"},
    {"id": "4", "type": "example", "text": "Real-world example"},
    {"id": "5", "type": "summary", "text": "Summary and key points"}
  ],
  "keyPoints": ["Point 1", "Point 2", "Point 3"],
  "analogies": ["Analogy 1", "Analogy 2"],
  "examples": ["Example 1", "Example 2"]
}`
            },
            {
              role: "user",
              content: `Create an engaging lesson from this content:\n\n${document.extractedText.slice(0, 3000)}`
            }
          ],
          temperature: 0.7,
        }),
      });

      if (!response.ok) {
        throw new Error(`OpenRouter API error: ${response.statusText}`);
      }

      const data = await response.json() as any;
      const content = JSON.parse(data.choices[0].message.content);

      // Create transcript from segments
      const transcript = content.segments.map((s: any) => s.text).join("\n\n");

      // Estimate duration (150 words per minute)
      const wordCount = transcript.split(/\s+/).length;
      const duration = Math.ceil(wordCount / 150);

      // Create lesson
      const lesson = await storage.createLesson({
        documentId: document.id,
        userId,
        title: content.title || document.title,
        content,
        transcript,
        duration,
      });

      // Generate quiz
      await generateQuiz(lesson.id, content);

      return lesson;
    } catch (error: any) {
      console.error("Lesson generation error:", error);
      
      // Fallback: Create a basic lesson without AI
      const fallbackContent = {
        segments: [
          {
            id: "1",
            type: "introduction" as const,
            text: `Welcome to this lesson about ${document.title}. Let's explore this topic together.`,
          },
          {
            id: "2",
            type: "explanation" as const,
            text: document.extractedText.slice(0, 500),
          },
          {
            id: "3",
            type: "summary" as const,
            text: "This concludes our lesson. Practice what you've learned in the quiz!",
          },
        ],
        keyPoints: ["Understanding the main concepts", "Applying knowledge practically"],
        analogies: [],
        examples: [],
      };

      const transcript = fallbackContent.segments.map(s => s.text).join("\n\n");
      const wordCount = transcript.split(/\s+/).length;
      const duration = Math.ceil(wordCount / 150);

      const lesson = await storage.createLesson({
        documentId: document.id,
        userId,
        title: document.title,
        content: fallbackContent,
        transcript,
        duration,
      });

      await generateQuiz(lesson.id, fallbackContent);
      return lesson;
    }
  }

  async function generateQuiz(lessonId: string, lessonContent: any) {
    try {
      // Call OpenRouter to generate quiz questions
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "anthropic/claude-3.5-sonnet",
          messages: [
            {
              role: "system",
              content: `Create 5 quiz questions to test understanding of the lesson. Mix multiple-choice and short-answer questions.
Format as JSON:
{
  "questions": [
    {
      "id": "1",
      "type": "multiple-choice",
      "question": "Question text?",
      "options": ["A", "B", "C", "D"],
      "correctAnswer": "B",
      "explanation": "Why this is correct"
    },
    {
      "id": "2",
      "type": "short-answer",
      "question": "Question text?",
      "correctAnswer": "Brief answer",
      "explanation": "Explanation"
    }
  ]
}`
            },
            {
              role: "user",
              content: `Create quiz questions for this lesson:\n${JSON.stringify(lessonContent).slice(0, 2000)}`
            }
          ],
          temperature: 0.7,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to generate quiz");
      }

      const data = await response.json() as any;
      const quizData = JSON.parse(data.choices[0].message.content);

      await storage.createQuiz({
        lessonId,
        questions: quizData.questions,
      });
    } catch (error: any) {
      console.error("Quiz generation error:", error);
      
      // Fallback: Create basic quiz
      const fallbackQuestions = [
        {
          id: "1",
          type: "multiple-choice",
          question: "What was the main topic of this lesson?",
          options: ["Option A", "Option B", "Option C", "Option D"],
          correctAnswer: "Option A",
          explanation: "This was the primary focus of the lesson.",
        },
      ];

      await storage.createQuiz({
        lessonId,
        questions: fallbackQuestions,
      });
    }
  }

  function calculateSimilarity(str1: string, str2: string): number {
    if (str1 === str2) return 1;
    if (str1.length === 0 || str2.length === 0) return 0;
    
    // Simple Levenshtein-based similarity
    const longer = str1.length > str2.length ? str1 : str2;
    const shorter = str1.length > str2.length ? str2 : str1;
    const longerLength = longer.length;
    
    if (longerLength === 0) return 1.0;
    
    const editDistance = levenshteinDistance(longer, shorter);
    return (longerLength - editDistance) / longerLength;
  }

  function levenshteinDistance(str1: string, str2: string): number {
    const matrix: number[][] = [];

    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i];
    }

    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j;
    }

    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          );
        }
      }
    }

    return matrix[str2.length][str1.length];
  }

  const httpServer = createServer(app);
  return httpServer;
}
