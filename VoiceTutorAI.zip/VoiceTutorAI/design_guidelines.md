# LearnVoice Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from modern educational platforms like Duolingo's playful engagement, Notion's clean content organization, and Linear's refined typography and spacing, while maintaining originality suited for voice-first learning.

**Core Principles**:
- Playful yet professional - inspire learning without feeling childish
- Voice-first interface patterns with clear audio controls
- Progressive disclosure - don't overwhelm, guide users step-by-step
- Achievement visibility - make progress tangible and rewarding

---

## Color Palette

### Light Mode
- **Primary Brand**: 245 75% 55% (vibrant purple-blue, energetic and educational)
- **Primary Hover**: 245 75% 48%
- **Secondary**: 200 85% 50% (bright cyan, for accent elements)
- **Success**: 142 70% 45% (green for correct answers, achievements)
- **Error**: 0 75% 55% (red for incorrect, alerts)
- **Background Base**: 0 0% 98%
- **Background Elevated**: 0 0% 100% (cards, modals)
- **Text Primary**: 240 10% 15%
- **Text Secondary**: 240 5% 45%

### Dark Mode
- **Primary Brand**: 245 65% 60%
- **Primary Hover**: 245 70% 65%
- **Secondary**: 200 75% 55%
- **Success**: 142 60% 50%
- **Error**: 0 65% 60%
- **Background Base**: 240 8% 12%
- **Background Elevated**: 240 6% 16%
- **Text Primary**: 0 0% 95%
- **Text Secondary**: 240 5% 65%

---

## Typography

**Font Families**:
- **Primary**: 'Inter' (headings, UI elements) - clean, modern, excellent readability
- **Secondary**: 'Space Grotesk' (brand elements, hero) - distinctive, friendly
- **Body**: 'Inter' (lesson content, descriptions)

**Scale**:
- Hero: text-5xl md:text-6xl font-bold (Space Grotesk)
- H1: text-4xl md:text-5xl font-bold
- H2: text-3xl md:text-4xl font-semibold
- H3: text-2xl md:text-3xl font-semibold
- Body Large: text-lg font-normal
- Body: text-base font-normal
- Body Small: text-sm font-normal
- Caption: text-xs font-medium

---

## Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24 for consistency
- Component padding: p-4, p-6, p-8
- Section spacing: py-12 md:py-20 lg:py-24
- Card gaps: gap-4, gap-6
- Element margins: mb-2, mb-4, mb-8

**Container Widths**:
- Full sections: w-full with max-w-7xl mx-auto px-4
- Content areas: max-w-4xl
- Lesson player: max-w-3xl
- Forms: max-w-md

**Grid Patterns**:
- Document cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Lesson features: grid-cols-1 md:grid-cols-2
- Quiz options: grid-cols-1 gap-3

---

## Component Library

### Navigation
- Clean top nav with logo (left), main links (center), profile/avatar (right)
- Mobile: Hamburger menu with slide-out drawer
- Active state: bottom border (3px) in primary color
- Background: bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg

### Cards
**Document Cards**:
- Rounded-xl, shadow-md hover:shadow-lg transition
- Thumbnail area (if PDF preview available)
- Title (text-lg font-semibold), excerpt (text-sm text-gray-600)
- Upload date badge, action buttons (Continue Learning, View Lesson)

**Lesson Cards**:
- Border-2 with gradient border on hover
- Icon or illustration (top), lesson title, duration estimate
- Progress bar at bottom (if in-progress)
- "Start Lesson" or "Resume" CTA

**Competition Cards**:
- Badge indicating "Active" or "Upcoming"
- Challenge title, participant count, end date
- Leaderboard preview (top 3 users)
- Join/View button

### Lesson Player Interface
- **Primary Area**: Large text display showing current lesson segment with subtle highlight animation as it's read
- **Audio Controls**: Play/pause (large center button), speed control (0.8x, 1x, 1.25x, 1.5x), progress bar with timestamps
- **Transcript Panel**: Collapsible side panel showing full transcript with current position highlighted
- **Voice Controls**: Microphone icon for voice input (when applicable), visual indicator when listening
- **Navigation**: Previous/Next segment buttons, bookmark/flag content button
- **Source Citations**: Inline citation chips linked to original document sections

### Quiz Interface
- **Question Card**: Large, centered, rounded-2xl with subtle shadow
- **Progress Indicator**: "Question 3 of 8" with visual progress bar
- **Answer Options**: 
  - MCQ: Large buttons (min-h-14) with radio circle, hover scale(1.02)
  - Short answer: Expanded textarea with character count
- **Feedback**: Animated check/cross, explanation card slides in below
- **Actions**: Submit button (prominent), Skip button (text-only, secondary)

### Dashboard Widgets
- **Learning Streak**: Flame icon, day count, calendar heatmap
- **Recent Lessons**: Horizontal scroll list with mini cards
- **Active Competitions**: Compact list with countdown timers
- **Progress Overview**: Circular progress charts for topics mastered
- **Voice Consent Status**: Banner with permission state, re-consent option

### Modals
- **Voice Consent**: 
  - Icon: Microphone with sound waves
  - Clear explanation of voice data usage
  - Privacy policy link
  - Sample recording UI (optional test)
  - Primary CTA: "Grant Permission", Secondary: "Learn More"
- **Content Flagging**:
  - Report type selector (Incorrect Info, Hallucination, Inappropriate)
  - Comment textarea
  - Specific segment identifier (auto-filled)
  - Submit/Cancel buttons

### Forms
- **Upload Interface**:
  - Large dropzone with dashed border, drag-and-drop
  - File icon, "Drop your PDF here or click to browse"
  - URL input field as alternative tab
  - Progress bar during processing
  - Success state with document preview

### Buttons
- **Primary**: bg-primary text-white rounded-lg px-6 py-3 font-semibold hover:bg-primary-hover
- **Secondary**: border-2 border-primary text-primary rounded-lg px-6 py-3 hover:bg-primary/5
- **Outline on Images**: bg-white/20 backdrop-blur-md border border-white/40 text-white (no hover states)
- **Icon Buttons**: Circular, p-3, hover:bg-gray-100 dark:hover:bg-gray-800

---

## Page Layouts

### Landing Page
- **Hero**: Full viewport (min-h-screen), gradient background (purple to blue), centered content
  - Main headline: "Learn Anything, Ask Everything" (Space Grotesk, text-5xl)
  - Subheadline: Voice-first AI tutor explanation
  - CTA: "Start Learning Free" (large primary button)
  - Hero illustration: Abstract learning/voice wave visualization
- **Features** (3 columns on desktop): Upload, AI Teaches, Quiz & Compete
- **How It Works** (4 steps): Visual timeline with icons
- **Social Proof**: User testimonials carousel
- **Final CTA**: Sign-up form embed or button

### Dashboard
- **Top Bar**: Welcome message, streak counter, quick actions
- **Main Grid** (2 columns on lg):
  - Left: Recent lessons, upload new document CTA
  - Right: Active competitions, progress stats
- **Bottom**: Recommended lessons based on history

### Document Upload Page
- Centered upload interface (max-w-2xl)
- Two tabs: "Upload PDF" and "Add URL"
- Processing state with animated loader
- Success state redirects to lesson generation

### Lesson Page
- **Layout**: Centered player (max-w-3xl), transcript sidebar (toggleable)
- **Background**: Subtle gradient or solid with elevation
- **Sticky Header**: Lesson title, back button, flag content
- **Footer**: Quiz launch CTA when lesson completes

### Competition Page
- **Header**: Challenge title, description, time remaining (countdown)
- **Leaderboard Table**: Rank, avatar, name, score, completion time
- **User Position**: Highlighted row if participating
- **CTA**: Join button (if not joined), Continue Learning (if joined)

### Admin Panel
- **Sidebar Navigation**: Reports, Content Flags, User Activity
- **Content Review**: Table with reported items, preview, approve/reject actions
- **Metrics Dashboard**: Total users, lessons created, quiz completion rate, flagged content count

---

## Images

**Hero Section**: Use a vibrant, modern illustration showing:
- A person with headphones/microphone engaging with floating UI elements
- Abstract wave forms representing voice/audio
- Color palette matching brand (purples, cyans, gradients)
- Style: Flat illustration with subtle gradients, modern and clean

**Feature Section Icons**: Use icon library (Material Icons) for Upload, Microphone, Quiz, Trophy icons

**Empty States**: Custom illustrations for:
- No documents uploaded yet
- No active competitions
- No quiz history

---

## Animations

**Use Sparingly**:
- Lesson text highlight: Smooth fade-in/color transition as narrated
- Quiz feedback: Scale + color change on answer selection
- Progress bars: Smooth width transition
- Card hover: Subtle lift (translateY(-2px)) + shadow increase
- Page transitions: Simple fade (200ms)

**Avoid**: Complex scroll animations, parallax effects, excessive motion

---

## Accessibility
- ARIA labels on all interactive elements, especially voice controls
- Keyboard navigation: tab order, focus visible rings (ring-2 ring-primary ring-offset-2)
- Voice control indicators clearly visible
- High contrast mode support
- Text remains readable in both light/dark modes
- Minimum touch target: 44x44px for mobile