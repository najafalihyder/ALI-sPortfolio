# LearnVoice - AI-Powered Voice-First Learning Platform

## Overview
LearnVoice is a modern web application that transforms documents into interactive, voice-enabled AI lessons. Users can upload PDFs or URLs, and the AI teaching agent "Mate" generates personalized lessons with analogies, examples, and quizzes. The platform features text-to-speech playback, intelligent quizzes with fuzzy matching, learning competitions, and content quality controls.

## Current Status (October 22, 2025)
✅ **FULLY OPERATIONAL** - The application is ready to use!

- ✅ Complete frontend implementation with all pages and components
- ✅ Firebase authentication with Google sign-in and email/password
- ✅ Full backend API with OpenRouter integration for AI lesson generation
- ✅ Voice-first lesson player with Web Speech API
- ✅ Quiz system with fuzzy answer matching (70% similarity threshold)
- ✅ Competition system with leaderboards
- ✅ Content flagging and admin review panel
- ✅ Voice consent workflow
- ✅ PDF text extraction using pdf-parse library
- ✅ URL content scraping with cheerio
- ✅ All environment secrets configured (OpenRouter API, Firebase)

## Quick Start

### Required Environment Variables
All secrets are already configured in Replit Secrets:
- `OPENROUTER_API_KEY` - For AI lesson generation (Claude 3.5 Sonnet)
- `VITE_FIREBASE_PROJECT_ID` - Firebase project ID
- `VITE_FIREBASE_APP_ID` - Firebase app ID
- `VITE_FIREBASE_API_KEY` - Firebase API key
- `SESSION_SECRET` - For session management

### Running the Application
The app is already running on port 5000! Just visit the webview.

To restart manually:
```bash
npm run dev
```

The server will:
1. Seed the database with sample competitions
2. Start Express backend on port 5000
3. Start Vite frontend dev server
4. Serve both frontend and API together

## User Preferences
- **AI Provider**: OpenRouter (flexible model selection, currently using Claude 3.5 Sonnet)
- **Authentication**: Firebase with Google OAuth and email/password
- **Database**: In-memory storage (MemStorage) for MVP - easily scalable to PostgreSQL
- **Voice**: Browser-based Web Speech API (no server-side processing needed)
- **Focus**: Teaching quality and UI/UX over monetization features

## Project Architecture

### Frontend (`client/`)
**Technology Stack:**
- React 18 with TypeScript
- Vite for build tooling
- TanStack Query for data fetching
- Wouter for routing
- Tailwind CSS + shadcn/ui components
- Firebase SDK for authentication

**Pages:**
- `/` - Landing page with hero, features, and CTAs
- `/signin` & `/signup` - Authentication pages
- `/dashboard` - User dashboard with recent lessons and stats
- `/upload` - Document upload (PDF/URL) with drag-and-drop
- `/lesson/:id` - Interactive lesson player with voice controls
- `/quiz/:id` - Quiz interface with instant feedback
- `/competitions` - Learning challenges and leaderboards
- `/admin` - Content report management

**Key Components:**
- `Navbar.tsx` - Navigation with user menu
- `ThemeToggle.tsx` & `ThemeProvider.tsx` - Dark/light mode
- `AuthContext.tsx` - Firebase auth state management
- `ProtectedRoute.tsx` - Route guards for authenticated pages
- `VoiceConsentModal.tsx` - Privacy-focused voice permission
- `FlagContentDialog.tsx` - Report content issues

### Backend (`server/`)
**Technology Stack:**
- Express.js with TypeScript
- Multer for file uploads (10MB limit)
- pdf-parse for PDF text extraction
- cheerio for URL content scraping
- node-fetch for HTTP requests
- OpenRouter API for AI lesson generation
- In-memory storage (IStorage interface)

**API Endpoints:**
```
POST   /api/auth/sync              - Sync Firebase user to database
POST   /api/documents/upload       - Upload PDF file (extracts text immediately)
POST   /api/documents/url          - Process URL content (scrapes with cheerio)
GET    /api/documents/user/:userId - Get user's documents
GET    /api/lessons/:id            - Get lesson by ID
GET    /api/lessons/user/:userId   - Get user's lessons
GET    /api/quizzes/:id            - Get quiz by ID
GET    /api/quizzes/lesson/:lessonId - Get quiz for lesson
POST   /api/quizzes/submit         - Submit quiz answers
GET    /api/competitions/active    - Get active competitions
GET    /api/competitions/user/:userId - Get user's competitions
POST   /api/competitions/join      - Join a competition
POST   /api/voice/consent          - Update voice consent
POST   /api/reports                - Create content report
GET    /api/reports/pending        - Get pending reports (admin)
POST   /api/reports/:id/review     - Review report (admin)
GET    /api/admin/stats            - Get platform statistics
```

**AI Integration:**
- Uses OpenRouter API with Claude 3.5 Sonnet for lesson generation
- High-quality prompts designed for pedagogical excellence
- Structured JSON responses with segments, analogies, examples
- Automatic quiz generation from lesson content
- Fuzzy matching for quiz answers (70% similarity threshold using Levenshtein distance)
- Fallback mechanisms if API fails (basic lesson/quiz generation)

### Shared Types (`shared/schema.ts`)
Complete TypeScript types and Drizzle ORM schemas for:
- Users, Documents, Lessons, Quizzes, QuizAttempts
- Competitions, CompetitionParticipants
- ContentReports

## How It Works

### Document Upload Flow
1. User uploads PDF or provides URL
2. **PDF**: Text extracted using pdf-parse library (minimum 50 characters required)
3. **URL**: Content scraped with cheerio (fetches HTML, removes scripts/styles, extracts main content)
4. Document saved to storage
5. **Lesson generation triggered immediately**:
   - OpenRouter API called with pedagogical prompt
   - Structured lesson created with segments (introduction, explanation, analogy, example, summary)
   - Transcript generated from segments
   - Duration estimated (150 words per minute)
6. **Quiz auto-generated** from lesson content
7. User redirected to lesson player

### Lesson Generation Prompt
The system uses a sophisticated prompt that instructs the AI to:
- Create clear, step-by-step explanations
- Provide relatable analogies connecting new concepts to familiar ideas
- Include concrete real-world examples
- Structure content with clear learning objectives
- Return structured JSON with segments, key points, analogies, examples

### Voice Playback
- Browser Web Speech API for text-to-speech
- No server-side processing required
- Privacy-focused consent workflow
- Playback speed controls (0.8x, 1x, 1.25x, 1.5x)
- Automatic progression through lesson segments
- Play/pause/skip controls

### Quiz Scoring
- **Multiple-choice**: Exact match required
- **Short-answer**: Fuzzy matching with 70% similarity threshold
- Levenshtein distance algorithm for similarity calculation
- Instant feedback on submission

## Design System

**Colors (Light Mode):**
- Primary: `245 75% 55%` (vibrant purple-blue)
- Secondary: `200 85% 50%` (bright cyan)
- Success: `142 70% 45%` (green)
- Error: `0 75% 55%` (red)

**Typography:**
- Primary: Inter (UI, body text)
- Brand: Space Grotesk (headings, hero)

**Component Patterns:**
- Cards with subtle elevation on hover
- Gradient backgrounds for hero sections
- Consistent spacing (4, 6, 8, 12, 16, 20, 24px units)
- Smooth transitions and animations
- Mobile-first responsive design

## Technical Implementation Details

### Authentication Flow
1. User signs in via Firebase (Google or email/password)
2. Firebase auth state change triggers sync with backend (`/api/auth/sync`)
3. User record created/updated in storage
4. Auth state persisted in AuthContext

### PDF Text Extraction
```typescript
// Uses pdf-parse v2 library with PDFParse class
import { PDFParse } from "pdf-parse";

// Create parser instance with buffer data
const parser = new PDFParse({ data: file.buffer });

// Extract text from all pages
const pdfData = await parser.getText();
const extractedText = pdfData.text.trim();

// Always call destroy() to free memory
await parser.destroy();

// Validates minimum 50 characters
// Handles errors gracefully with user-friendly messages
```

**Note**: In production code, use a `try-finally` block to ensure `parser.destroy()` is called even if extraction fails.

### URL Content Scraping
```typescript
// Fetches URL with proper User-Agent
const response = await fetch(url, {
  headers: { 'User-Agent': 'Mozilla/5.0 (compatible; LearnVoiceBot/1.0)' }
});
const html = await response.text();
const $ = cheerio.load(html);

// Removes unwanted elements
$('script, style, nav, header, footer, aside').remove();

// Prioritizes main content areas
const contentSelectors = ['article', 'main', '[role="main"]', '.post-content', '.article-content', '.entry-content', 'body'];

// Extracts and cleans text (limit: 50,000 characters)
```

### OpenRouter API Integration
```typescript
const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
  method: "POST",
  headers: {
    "Authorization": `Bearer ${process.env.OPENROUTER_API_KEY}`,
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    model: "anthropic/claude-3.5-sonnet",
    messages: [
      { role: "system", content: "Pedagogical prompt..." },
      { role: "user", content: `Create lesson from: ${extractedText}` }
    ],
    temperature: 0.7,
  }),
});
```

### Voice Features (Web Speech API)
```typescript
const utterance = new SpeechSynthesisUtterance(text);
utterance.rate = playbackRate; // 0.8x, 1x, 1.25x, 1.5x
utterance.onend = () => {
  // Auto-advance to next segment
};
window.speechSynthesis.speak(utterance);
```

## File Structure
```
client/
  src/
    components/       # Reusable UI components (shadcn/ui)
    contexts/        # React contexts (Auth, Theme)
    lib/            # Utilities (Firebase, QueryClient)
    pages/          # Page components
    
server/
  index.ts         # Express server setup
  routes.ts        # All API endpoints + AI logic
  storage.ts       # Storage interface & in-memory implementation
  seed.ts          # Database seeding

shared/
  schema.ts        # Shared TypeScript types
```

## Development Best Practices
- TypeScript for type safety across stack
- TanStack Query for efficient data fetching
- Optimistic updates where appropriate
- Error boundaries and graceful degradation
- Accessibility (ARIA labels, keyboard navigation)
- Mobile-first responsive design
- Component reusability and composition
- Async/await throughout for performance

## Features Implemented
✅ Firebase Authentication (Google + Email/Password)
✅ PDF text extraction with pdf-parse
✅ URL content scraping with cheerio
✅ AI lesson generation with OpenRouter (Claude 3.5 Sonnet)
✅ Voice-first lesson player (Text-to-Speech via Web Speech API)
✅ Interactive quizzes with fuzzy matching (Levenshtein distance)
✅ Learning competitions and leaderboards
✅ Voice consent workflow
✅ Content flagging and admin review
✅ Dark mode support
✅ Fully responsive mobile-first design
✅ Loading states and error handling
✅ Fallback mechanisms for API failures

## Performance Optimizations
- In-memory storage for fast development (no DB overhead)
- Async/await throughout for non-blocking operations
- Efficient text extraction (limits: 50K chars for URLs)
- Smart content selectors for URL scraping
- Client-side Web Speech API (no server processing)
- TanStack Query caching and optimistic updates
- Vite for fast builds and HMR

## Future Enhancements (Not Yet Implemented)
- [ ] PostgreSQL database for persistence
- [ ] Vector embeddings with ChromaDB for semantic search
- [ ] Speech-to-text for voice questions
- [ ] Advanced AI personalization with user memory
- [ ] Spaced repetition algorithm
- [ ] Collaborative learning features
- [ ] Lesson bookmarking and note-taking
- [ ] Export functionality (PDF summaries, flashcards)
- [ ] Multi-language support
- [ ] Offline mode
- [ ] Mobile apps (React Native)

## Troubleshooting

### Common Issues

**Lesson generation fails:**
- Check OPENROUTER_API_KEY is set correctly
- Verify API quota/credits at https://openrouter.ai
- Check server logs for detailed error messages
- Fallback: App creates basic lesson without AI

**Voice playback not working:**
- Ensure using a modern browser (Chrome, Edge, Safari)
- Check browser permissions for audio
- Some browsers require user interaction before TTS works
- Grant voice consent when prompted

**PDF upload fails:**
- Ensure PDF contains readable text (not scanned images)
- Check file size is under 10MB
- Verify PDF is not password-protected

**URL processing fails:**
- Verify URL is publicly accessible
- Some sites block scraping (403/429 errors)
- Try different article URLs if one fails

## Deployment Notes
- Currently uses in-memory storage (data resets on restart)
- For production: migrate to PostgreSQL
- Configure Firebase for production domain
- Set up proper CORS headers
- Add rate limiting for API endpoints
- Monitor OpenRouter API usage

## API Keys Management
All API keys are managed through Replit Secrets:
- Keys are never exposed in code
- Accessed via `process.env.VARIABLE_NAME`
- Frontend keys prefixed with `VITE_` for build-time access
- Session secret for Express session management

## Contact & Support
For questions about the codebase or features, refer to this documentation.
For API key setup, visit:
- OpenRouter: https://openrouter.ai
- Firebase: https://console.firebase.google.com
