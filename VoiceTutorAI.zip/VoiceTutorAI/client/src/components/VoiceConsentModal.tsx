import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Mic, Shield, Loader2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface VoiceConsentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function VoiceConsentModal({ open, onOpenChange }: VoiceConsentModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();

  const consentMutation = useMutation({
    mutationFn: async (granted: boolean) => {
      return await apiRequest("POST", "/api/voice/consent", {
        userId: user?.uid,
        granted,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", user?.uid] });
      toast({
        title: "Preferences saved",
        description: "Your voice consent preferences have been updated.",
      });
      onOpenChange(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save preferences. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="mx-auto mb-4 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
            <Mic className="h-6 w-6 text-primary" />
          </div>
          <DialogTitle className="text-center">Voice Features Consent</DialogTitle>
          <DialogDescription className="text-center">
            LearnVoice uses text-to-speech to read lessons aloud. We respect your privacy and want to ensure you're comfortable with voice features.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="flex gap-3 p-4 bg-muted/30 rounded-lg">
            <Shield className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium mb-1">Your Privacy Matters</p>
              <p className="text-muted-foreground">
                Voice synthesis happens in your browser using Web Speech API. No audio data is recorded or sent to our servers.
              </p>
            </div>
          </div>

          <div className="text-xs text-muted-foreground space-y-1">
            <p>• Text-to-speech is processed locally in your browser</p>
            <p>• No voice recordings are made or stored</p>
            <p>• You can change this preference anytime in settings</p>
          </div>
        </div>

        <DialogFooter className="flex-col sm:flex-col gap-2">
          <Button
            onClick={() => consentMutation.mutate(true)}
            disabled={consentMutation.isPending}
            className="w-full"
            data-testid="button-grant-consent"
          >
            {consentMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Grant Permission
          </Button>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={consentMutation.isPending}
            className="w-full"
            data-testid="button-cancel-consent"
          >
            Not Now
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
