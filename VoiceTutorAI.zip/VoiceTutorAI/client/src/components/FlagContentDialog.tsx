import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Flag, Loader2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface FlagContentDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  lessonId: string;
  segmentReference?: string;
}

export function FlagContentDialog({
  open,
  onOpenChange,
  lessonId,
  segmentReference,
}: FlagContentDialogProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [reportType, setReportType] = useState<string>("incorrect");
  const [description, setDescription] = useState("");

  const reportMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/reports", {
        userId: user?.uid,
        lessonId,
        reportType,
        description,
        segmentReference,
      });
    },
    onSuccess: () => {
      toast({
        title: "Report submitted",
        description: "Thank you for helping us improve lesson quality!",
      });
      setDescription("");
      setReportType("incorrect");
      onOpenChange(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit report. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) {
      toast({
        title: "Description required",
        description: "Please provide details about the issue.",
        variant: "destructive",
      });
      return;
    }
    reportMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="mx-auto mb-4 w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center">
            <Flag className="h-6 w-6 text-destructive" />
          </div>
          <DialogTitle className="text-center">Report Content Issue</DialogTitle>
          <DialogDescription className="text-center">
            Help us maintain teaching quality by reporting incorrect information or issues
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-3">
            <Label>Issue Type</Label>
            <RadioGroup value={reportType} onValueChange={setReportType}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="incorrect" id="incorrect" data-testid="radio-incorrect" />
                <Label htmlFor="incorrect" className="font-normal cursor-pointer">
                  Incorrect Information
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="hallucination" id="hallucination" data-testid="radio-hallucination" />
                <Label htmlFor="hallucination" className="font-normal cursor-pointer">
                  AI Hallucination
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="inappropriate" id="inappropriate" data-testid="radio-inappropriate" />
                <Label htmlFor="inappropriate" className="font-normal cursor-pointer">
                  Inappropriate Content
                </Label>
              </div>
            </RadioGroup>
          </div>

          {segmentReference && (
            <div className="text-sm text-muted-foreground bg-muted/30 p-3 rounded-md">
              <span className="font-medium">Location: </span>
              {segmentReference}
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Please describe the issue in detail..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              required
              data-testid="input-description"
            />
          </div>

          <DialogFooter className="flex-col sm:flex-col gap-2">
            <Button
              type="submit"
              disabled={reportMutation.isPending}
              className="w-full"
              data-testid="button-submit-report"
            >
              {reportMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Submit Report
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={reportMutation.isPending}
              className="w-full"
              data-testid="button-cancel-report"
            >
              Cancel
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
