import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Upload, Mic, Trophy, MessageSquare, Shield, Sparkles } from "lucide-react";
import { ThemeToggle } from "@/components/ThemeToggle";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Sparkles className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold font-brand">LearnVoice</span>
            </div>
            <div className="flex items-center gap-4">
              <ThemeToggle />
              <Link href="/signin">
                <Button variant="ghost" data-testid="button-signin">
                  Sign In
                </Button>
              </Link>
              <Link href="/signup">
                <Button data-testid="button-signup">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
        {/* Gradient Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-chart-2/10" />
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold font-brand mb-6 bg-gradient-to-r from-primary via-chart-2 to-primary bg-clip-text text-transparent">
              Learn Anything, Ask Everything
            </h1>
            <p className="text-xl sm:text-2xl text-muted-foreground mb-8 leading-relaxed">
              Your AI teaching companion that transforms documents into interactive spoken lessons. 
              Upload, listen, learn, and compete with others.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/signup">
                <Button size="lg" className="text-lg px-8 py-6" data-testid="button-hero-start">
                  Start Learning Free
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="text-lg px-8 py-6" data-testid="button-how-it-works">
                How It Works
              </Button>
            </div>
          </div>

          {/* Feature Highlights */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20 max-w-5xl mx-auto">
            <Card className="hover-elevate">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Upload className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Upload & Learn</h3>
                <p className="text-sm text-muted-foreground">
                  Upload PDFs or paste URLs. Our AI extracts and organizes the content for you.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-xl bg-chart-2/10 flex items-center justify-center mx-auto mb-4">
                  <Mic className="h-6 w-6 text-chart-2" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Voice-First Lessons</h3>
                <p className="text-sm text-muted-foreground">
                  Listen to AI-generated lessons with analogies, examples, and clear explanations.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 rounded-xl bg-chart-3/10 flex items-center justify-center mx-auto mb-4">
                  <Trophy className="h-6 w-6 text-chart-3" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Quiz & Compete</h3>
                <p className="text-sm text-muted-foreground">
                  Test your knowledge with quizzes and compete in learning challenges.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-card/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl font-bold font-brand mb-4">
              How LearnVoice Works
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Four simple steps to transform any document into an engaging learning experience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { step: "1", title: "Upload", desc: "Drop your PDF or paste a URL", icon: Upload },
              { step: "2", title: "AI Teaches", desc: "Mate generates personalized lessons", icon: MessageSquare },
              { step: "3", title: "Listen & Learn", desc: "Engage with voice-first content", icon: Mic },
              { step: "4", title: "Test & Compete", desc: "Quiz yourself and join challenges", icon: Trophy },
            ].map((item) => (
              <div key={item.step} className="text-center">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <item.icon className="h-8 w-8 text-primary" />
                </div>
                <div className="text-3xl font-bold font-brand text-primary mb-2">
                  {item.step}
                </div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Detail */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold font-brand mb-6">
                High-Quality Teaching, Powered by AI
              </h2>
              <div className="space-y-4">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Sparkles className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Analogies & Examples</h3>
                    <p className="text-muted-foreground">
                      Complex concepts explained through relatable analogies and real-world examples.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <MessageSquare className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Interactive Transcripts</h3>
                    <p className="text-muted-foreground">
                      Follow along with highlighted transcripts and source citations.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Shield className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1">Quality Control</h3>
                    <p className="text-muted-foreground">
                      Report incorrect information and help maintain teaching quality.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-br from-primary/20 to-chart-2/20 rounded-2xl p-12 flex items-center justify-center min-h-[400px]">
              <div className="text-center">
                <Mic className="h-24 w-24 text-primary mx-auto mb-4 opacity-50" />
                <p className="text-lg text-muted-foreground">Voice-First Learning Experience</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary/5">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl sm:text-5xl font-bold font-brand mb-6">
            Ready to Transform Your Learning?
          </h2>
          <p className="text-xl text-muted-foreground mb-8">
            Join thousands of learners using AI to master any topic
          </p>
          <Link href="/signup">
            <Button size="lg" className="text-lg px-10 py-6" data-testid="button-cta-signup">
              Start Learning Free
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              <span className="font-bold font-brand">LearnVoice</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 LearnVoice. Powered by AI. Built for learners.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
