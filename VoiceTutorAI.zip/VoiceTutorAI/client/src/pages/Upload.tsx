import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/contexts/AuthContext";
import { Upload as UploadIcon, Link as LinkIcon, Loader2, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

function UploadContent() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [url, setUrl] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);

  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      return await apiRequest("POST", "/api/documents/upload", formData);
    },
    onSuccess: (data: any) => {
      toast({
        title: "Document uploaded!",
        description: "Generating your AI lesson...",
      });
      setLocation(`/lesson/${data.lessonId}`);
    },
    onError: (error: any) => {
      toast({
        title: "Upload failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  const urlMutation = useMutation({
    mutationFn: async (url: string) => {
      return await apiRequest("POST", "/api/documents/url", { url, userId: user?.uid });
    },
    onSuccess: (data: any) => {
      toast({
        title: "URL processed!",
        description: "Generating your AI lesson...",
      });
      setLocation(`/lesson/${data.lessonId}`);
    },
    onError: (error: any) => {
      toast({
        title: "Processing failed",
        description: error.message || "Please check the URL and try again.",
        variant: "destructive",
      });
    },
  });

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile.type === "application/pdf") {
        setFile(droppedFile);
      } else {
        toast({
          title: "Invalid file type",
          description: "Please upload a PDF file.",
          variant: "destructive",
        });
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handlePdfUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);
    formData.append("userId", user?.uid || "");
    uploadMutation.mutate(formData);
  };

  const handleUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    urlMutation.mutate(url);
  };

  const isLoading = uploadMutation.isPending || urlMutation.isPending;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold font-brand mb-4">
            Upload Learning Material
          </h1>
          <p className="text-lg text-muted-foreground">
            Upload a PDF or paste a URL to generate an AI-powered lesson
          </p>
        </div>

        <Tabs defaultValue="pdf" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="pdf" className="gap-2" data-testid="tab-pdf">
              <FileText className="h-4 w-4" />
              PDF Upload
            </TabsTrigger>
            <TabsTrigger value="url" className="gap-2" data-testid="tab-url">
              <LinkIcon className="h-4 w-4" />
              Web URL
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pdf">
            <Card>
              <CardHeader>
                <CardTitle>Upload PDF Document</CardTitle>
                <CardDescription>
                  Drag and drop your PDF file or click to browse
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handlePdfUpload} className="space-y-6">
                  <div
                    className={`relative border-2 border-dashed rounded-lg p-12 text-center transition-colors ${
                      dragActive
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                    onDragEnter={handleDrag}
                    onDragLeave={handleDrag}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                  >
                    <input
                      type="file"
                      id="file-upload"
                      accept="application/pdf"
                      onChange={handleFileChange}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      disabled={isLoading}
                      data-testid="input-file"
                    />
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                        <UploadIcon className="h-8 w-8 text-primary" />
                      </div>
                      {file ? (
                        <div>
                          <p className="font-medium text-primary">{file.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {(file.size / 1024 / 1024).toFixed(2)} MB
                          </p>
                        </div>
                      ) : (
                        <div>
                          <p className="font-medium mb-1">Drop your PDF here or click to browse</p>
                          <p className="text-sm text-muted-foreground">
                            Support for PDF files up to 10MB
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="w-full"
                    disabled={!file || isLoading}
                    data-testid="button-upload-pdf"
                  >
                    {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {isLoading ? "Processing..." : "Generate Lesson"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="url">
            <Card>
              <CardHeader>
                <CardTitle>Add Web URL</CardTitle>
                <CardDescription>
                  Paste a link to an article, blog post, or webpage
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleUrlSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="url">URL</Label>
                    <Input
                      id="url"
                      type="url"
                      placeholder="https://example.com/article"
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                      required
                      disabled={isLoading}
                      data-testid="input-url"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full"
                    disabled={!url || isLoading}
                    data-testid="button-submit-url"
                  >
                    {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {isLoading ? "Processing..." : "Generate Lesson"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-8 p-6 bg-muted/30 rounded-lg">
          <h3 className="font-semibold mb-2">What happens next?</h3>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex gap-2">
              <span className="text-primary">1.</span>
              <span>We extract and analyze the content from your document</span>
            </li>
            <li className="flex gap-2">
              <span className="text-primary">2.</span>
              <span>Our AI teacher "Mate" creates a personalized lesson with analogies and examples</span>
            </li>
            <li className="flex gap-2">
              <span className="text-primary">3.</span>
              <span>You can listen to the lesson with voice playback and interactive transcripts</span>
            </li>
            <li className="flex gap-2">
              <span className="text-primary">4.</span>
              <span>Test your knowledge with automatically generated quizzes</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default function Upload() {
  return (
    <ProtectedRoute>
      <UploadContent />
    </ProtectedRoute>
  );
}
