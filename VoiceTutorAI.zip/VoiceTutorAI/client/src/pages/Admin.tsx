import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Navbar } from "@/components/Navbar";
import { Flag, Users, BookOpen, Trophy, CheckCircle, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { ContentReport } from "@shared/schema";
import { useState } from "react";

function AdminContent() {
  const { toast } = useToast();
  const [adminNotes, setAdminNotes] = useState<Record<string, string>>({});

  const { data: reports, isLoading } = useQuery<ContentReport[]>({
    queryKey: ["/api/reports/pending"],
  });

  const { data: stats } = useQuery<any>({
    queryKey: ["/api/admin/stats"],
  });

  const reviewMutation = useMutation({
    mutationFn: async ({ reportId, status, notes }: { reportId: string; status: string; notes?: string }) => {
      return await apiRequest("POST", `/api/reports/${reportId}/review`, {
        status,
        adminNotes: notes,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports/pending"] });
      toast({
        title: "Report reviewed",
        description: "Status updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update report status.",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold font-brand mb-2">Admin Panel</h1>
          <p className="text-lg text-muted-foreground">
            Manage content reports and monitor platform metrics
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{stats?.totalUsers || 0}</div>
                  <div className="text-sm text-muted-foreground">Total Users</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-chart-2/10 flex items-center justify-center">
                  <BookOpen className="h-6 w-6 text-chart-2" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{stats?.totalLessons || 0}</div>
                  <div className="text-sm text-muted-foreground">Lessons Created</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-chart-3/10 flex items-center justify-center">
                  <Trophy className="h-6 w-6 text-chart-3" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{stats?.totalCompetitions || 0}</div>
                  <div className="text-sm text-muted-foreground">Competitions</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-destructive/10 flex items-center justify-center">
                  <Flag className="h-6 w-6 text-destructive" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{stats?.pendingReports || 0}</div>
                  <div className="text-sm text-muted-foreground">Pending Reports</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Content Reports */}
        <div>
          <h2 className="text-2xl font-bold font-brand mb-6">Content Reports</h2>
          
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Card key={i}>
                  <CardHeader>
                    <Skeleton className="h-6 w-1/2" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-20 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : reports && reports.length > 0 ? (
            <div className="space-y-4">
              {reports.map((report) => (
                <Card key={report.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge
                            variant={
                              report.reportType === "incorrect"
                                ? "destructive"
                                : report.reportType === "hallucination"
                                ? "default"
                                : "secondary"
                            }
                            className="capitalize"
                          >
                            {report.reportType}
                          </Badge>
                          <Badge variant="outline">{report.status}</Badge>
                        </div>
                        <CardDescription className="text-xs">
                          Reported on {new Date(report.createdAt).toLocaleDateString()} by User {report.userId.slice(0, 8)}
                          {report.segmentReference && ` • ${report.segmentReference}`}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-muted/30 rounded-lg">
                      <p className="text-sm">{report.description}</p>
                    </div>

                    <div className="space-y-2">
                      <Textarea
                        placeholder="Admin notes (optional)..."
                        value={adminNotes[report.id] || ""}
                        onChange={(e) => setAdminNotes({ ...adminNotes, [report.id]: e.target.value })}
                        rows={2}
                        data-testid={`textarea-notes-${report.id}`}
                      />
                    </div>

                    <div className="flex gap-2">
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() =>
                          reviewMutation.mutate({
                            reportId: report.id,
                            status: "resolved",
                            notes: adminNotes[report.id],
                          })
                        }
                        disabled={reviewMutation.isPending}
                        data-testid={`button-resolve-${report.id}`}
                      >
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Resolve
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() =>
                          reviewMutation.mutate({
                            reportId: report.id,
                            status: "rejected",
                            notes: adminNotes[report.id],
                          })
                        }
                        disabled={reviewMutation.isPending}
                        data-testid={`button-reject-${report.id}`}
                      >
                        <XCircle className="mr-2 h-4 w-4" />
                        Reject
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Flag className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No pending reports</h3>
                <p className="text-muted-foreground">All content reports have been reviewed</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Admin() {
  return (
    <ProtectedRoute>
      <AdminContent />
    </ProtectedRoute>
  );
}
