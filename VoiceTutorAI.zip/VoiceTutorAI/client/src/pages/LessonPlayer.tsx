import { useState, useEffect, useRef } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Navbar } from "@/components/Navbar";
import { Play, Pause, SkipBack, SkipForward, Volume2, Flag, BookOpen } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Lesson, LessonContent, LessonSegment } from "@shared/schema";
import { VoiceConsentModal } from "@/components/VoiceConsentModal";
import { FlagContentDialog } from "@/components/FlagContentDialog";

function LessonPlayerContent() {
  const [, params] = useRoute("/lesson/:id");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentSegment, setCurrentSegment] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [showConsent, setShowConsent] = useState(false);
  const [showFlagDialog, setShowFlagDialog] = useState(false);
  const synthRef = useRef<SpeechSynthesisUtterance | null>(null);

  const { data: lesson, isLoading } = useQuery<Lesson>({
    queryKey: ["/api/lessons", params?.id],
    enabled: !!params?.id,
  });

  const { data: quiz } = useQuery({
    queryKey: ["/api/quizzes/lesson", params?.id],
    enabled: !!params?.id,
  });

  const content = lesson?.content as LessonContent | undefined;
  const segments = content?.segments || [];
  const currentSegmentData = segments[currentSegment];

  useEffect(() => {
    return () => {
      window.speechSynthesis.cancel();
    };
  }, []);

  const speak = (text: string) => {
    if (!("speechSynthesis" in window)) {
      toast({
        title: "Not supported",
        description: "Text-to-speech is not supported in your browser.",
        variant: "destructive",
      });
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = playbackRate;
    utterance.onend = () => {
      if (currentSegment < segments.length - 1) {
        setCurrentSegment((prev) => prev + 1);
      } else {
        setIsPlaying(false);
      }
    };
    synthRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  };

  const togglePlay = () => {
    if (isPlaying) {
      window.speechSynthesis.pause();
      setIsPlaying(false);
    } else {
      if (window.speechSynthesis.paused) {
        window.speechSynthesis.resume();
      } else {
        speak(currentSegmentData?.text || "");
      }
      setIsPlaying(true);
    }
  };

  const handleNext = () => {
    if (currentSegment < segments.length - 1) {
      setCurrentSegment((prev) => prev + 1);
      if (isPlaying) {
        window.speechSynthesis.cancel();
        speak(segments[currentSegment + 1]?.text || "");
      }
    }
  };

  const handlePrevious = () => {
    if (currentSegment > 0) {
      setCurrentSegment((prev) => prev - 1);
      if (isPlaying) {
        window.speechSynthesis.cancel();
        speak(segments[currentSegment - 1]?.text || "");
      }
    }
  };

  const startQuiz = () => {
    if (quiz) {
      setLocation(`/quiz/${quiz.id}`);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Skeleton className="h-12 w-3/4 mb-4" />
          <Skeleton className="h-64 w-full mb-4" />
          <Skeleton className="h-20 w-full" />
        </div>
      </div>
    );
  }

  if (!lesson) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <h2 className="text-2xl font-bold mb-4">Lesson not found</h2>
          <Button onClick={() => setLocation("/dashboard")}>Back to Dashboard</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Lesson Header */}
        <div className="mb-8">
          <div className="flex items-start justify-between gap-4 mb-4">
            <div>
              <h1 className="text-4xl font-bold font-brand mb-2">{lesson.title}</h1>
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <span>{lesson.duration} min lesson</span>
                <span>•</span>
                <span>{segments.length} segments</span>
              </div>
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setShowFlagDialog(true)}
              data-testid="button-flag"
            >
              <Flag className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Lesson Player */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge variant={currentSegmentData?.type === "introduction" ? "default" : "secondary"}>
                  {currentSegmentData?.type || "segment"}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  Segment {currentSegment + 1} of {segments.length}
                </span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Current Segment Text */}
            <div className="p-6 bg-muted/30 rounded-lg min-h-[200px]">
              <p className="text-lg leading-relaxed">
                {currentSegmentData?.text || "No content available"}
              </p>
              {currentSegmentData?.sourceReference && (
                <p className="text-sm text-muted-foreground mt-4 italic">
                  Source: {currentSegmentData.sourceReference}
                </p>
              )}
            </div>

            {/* Progress */}
            <div className="space-y-2">
              <Slider
                value={[currentSegment]}
                max={Math.max(0, segments.length - 1)}
                step={1}
                onValueChange={(value) => {
                  setCurrentSegment(value[0]);
                  if (isPlaying) {
                    window.speechSynthesis.cancel();
                    speak(segments[value[0]]?.text || "");
                  }
                }}
                data-testid="slider-progress"
              />
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-4">
              <Button
                variant="outline"
                size="icon"
                onClick={handlePrevious}
                disabled={currentSegment === 0}
                data-testid="button-previous"
              >
                <SkipBack className="h-4 w-4" />
              </Button>
              
              <Button
                size="icon"
                className="h-14 w-14"
                onClick={togglePlay}
                data-testid="button-play"
              >
                {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6 ml-1" />}
              </Button>

              <Button
                variant="outline"
                size="icon"
                onClick={handleNext}
                disabled={currentSegment === segments.length - 1}
                data-testid="button-next"
              >
                <SkipForward className="h-4 w-4" />
              </Button>
            </div>

            {/* Playback Speed */}
            <div className="flex items-center justify-center gap-2">
              <Volume2 className="h-4 w-4 text-muted-foreground" />
              <div className="flex gap-1">
                {[0.8, 1, 1.25, 1.5].map((rate) => (
                  <Button
                    key={rate}
                    variant={playbackRate === rate ? "default" : "outline"}
                    size="sm"
                    onClick={() => setPlaybackRate(rate)}
                    data-testid={`button-speed-${rate}`}
                  >
                    {rate}x
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Key Points */}
        {content?.keyPoints && content.keyPoints.length > 0 && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="text-lg">Key Takeaways</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {content.keyPoints.map((point, idx) => (
                  <li key={idx} className="flex gap-3">
                    <span className="text-primary font-semibold">{idx + 1}.</span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}

        {/* Quiz CTA */}
        {quiz && (
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold mb-1">Ready to test your knowledge?</h3>
                  <p className="text-sm text-muted-foreground">
                    Take the quiz to reinforce what you've learned
                  </p>
                </div>
                <Button onClick={startQuiz} data-testid="button-start-quiz">
                  <BookOpen className="mr-2 h-4 w-4" />
                  Start Quiz
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <VoiceConsentModal open={showConsent} onOpenChange={setShowConsent} />
      <FlagContentDialog
        open={showFlagDialog}
        onOpenChange={setShowFlagDialog}
        lessonId={lesson.id}
        segmentReference={`Segment ${currentSegment + 1}`}
      />
    </div>
  );
}

export default function LessonPlayer() {
  return (
    <ProtectedRoute>
      <LessonPlayerContent />
    </ProtectedRoute>
  );
}
