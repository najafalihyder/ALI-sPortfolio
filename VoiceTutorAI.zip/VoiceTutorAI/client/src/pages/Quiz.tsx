import { useState } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/contexts/AuthContext";
import { CheckCircle2, XCircle, Loader2, Trophy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Quiz as QuizType, QuizQuestion } from "@shared/schema";

function QuizContent() {
  const [, params] = useRoute("/quiz/:id");
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [feedback, setFeedback] = useState<{ correct: boolean; explanation: string } | null>(null);
  const [score, setScore] = useState<number | null>(null);

  const { data: quiz, isLoading } = useQuery<QuizType>({
    queryKey: ["/api/quizzes", params?.id],
    enabled: !!params?.id,
  });

  const submitMutation = useMutation({
    mutationFn: async (finalAnswers: Record<number, string>) => {
      return await apiRequest("POST", "/api/quizzes/submit", {
        quizId: params?.id,
        userId: user?.uid,
        answers: finalAnswers,
      });
    },
    onSuccess: (data: any) => {
      setScore(data.score);
      toast({
        title: "Quiz completed!",
        description: `You scored ${data.score}%`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit quiz. Please try again.",
        variant: "destructive",
      });
    },
  });

  const questions = (quiz?.questions as QuizQuestion[]) || [];
  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  const handleAnswer = (answer: string) => {
    setAnswers({ ...answers, [currentQuestion]: answer });
  };

  const checkAnswer = () => {
    if (!question || !answers[currentQuestion]) {
      toast({
        title: "No answer selected",
        description: "Please select an answer before checking.",
        variant: "destructive",
      });
      return;
    }

    const userAnswer = answers[currentQuestion].toLowerCase().trim();
    const correctAnswer = question.correctAnswer.toLowerCase().trim();
    const isCorrect = userAnswer === correctAnswer;

    setFeedback({
      correct: isCorrect,
      explanation: question.explanation,
    });
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setFeedback(null);
    } else {
      // Submit quiz
      submitMutation.mutate(answers);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Skeleton className="h-8 w-full mb-4" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  if (!quiz || questions.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <h2 className="text-2xl font-bold mb-4">Quiz not found</h2>
          <Button onClick={() => setLocation("/dashboard")}>Back to Dashboard</Button>
        </div>
      </div>
    );
  }

  if (score !== null) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Card className="text-center">
            <CardContent className="p-12">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                <Trophy className="h-10 w-10 text-primary" />
              </div>
              <h2 className="text-4xl font-bold font-brand mb-4">Quiz Complete!</h2>
              <div className="text-6xl font-bold text-primary mb-6">{score}%</div>
              <p className="text-lg text-muted-foreground mb-8">
                You got {Math.round((score / 100) * questions.length)} out of {questions.length} questions correct
              </p>
              <div className="flex gap-4 justify-center">
                <Button onClick={() => setLocation("/dashboard")} data-testid="button-dashboard">
                  Back to Dashboard
                </Button>
                <Button variant="outline" onClick={() => window.location.reload()} data-testid="button-retake">
                  Retake Quiz
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">
              Question {currentQuestion + 1} of {questions.length}
            </span>
            <span className="text-sm text-muted-foreground">{Math.round(progress)}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Question Card */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl leading-relaxed">{question.question}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Answer Options */}
            {question.type === "multiple-choice" && question.options ? (
              <RadioGroup
                value={answers[currentQuestion]}
                onValueChange={handleAnswer}
                disabled={!!feedback}
              >
                <div className="space-y-3">
                  {question.options.map((option, idx) => (
                    <div
                      key={idx}
                      className={`flex items-center space-x-3 p-4 rounded-lg border-2 transition-colors ${
                        answers[currentQuestion] === option
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <RadioGroupItem value={option} id={`option-${idx}`} data-testid={`option-${idx}`} />
                      <Label htmlFor={`option-${idx}`} className="flex-1 cursor-pointer font-normal">
                        {option}
                      </Label>
                    </div>
                  ))}
                </div>
              </RadioGroup>
            ) : (
              <div className="space-y-2">
                <Label htmlFor="answer">Your Answer</Label>
                <Input
                  id="answer"
                  placeholder="Type your answer..."
                  value={answers[currentQuestion] || ""}
                  onChange={(e) => handleAnswer(e.target.value)}
                  disabled={!!feedback}
                  data-testid="input-answer"
                />
              </div>
            )}

            {/* Feedback */}
            {feedback && (
              <div className={`p-4 rounded-lg border-2 ${
                feedback.correct
                  ? "bg-chart-3/10 border-chart-3"
                  : "bg-destructive/10 border-destructive"
              }`}>
                <div className="flex items-center gap-2 mb-2">
                  {feedback.correct ? (
                    <CheckCircle2 className="h-5 w-5 text-chart-3" />
                  ) : (
                    <XCircle className="h-5 w-5 text-destructive" />
                  )}
                  <span className="font-semibold">
                    {feedback.correct ? "Correct!" : "Not quite"}
                  </span>
                </div>
                <p className="text-sm">{feedback.explanation}</p>
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-3">
              {!feedback ? (
                <Button
                  className="flex-1"
                  onClick={checkAnswer}
                  disabled={!answers[currentQuestion]}
                  data-testid="button-check"
                >
                  Check Answer
                </Button>
              ) : (
                <Button
                  className="flex-1"
                  onClick={handleNext}
                  disabled={submitMutation.isPending}
                  data-testid="button-next"
                >
                  {submitMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {currentQuestion < questions.length - 1 ? "Next Question" : "Finish Quiz"}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default function Quiz() {
  return (
    <ProtectedRoute>
      <QuizContent />
    </ProtectedRoute>
  );
}
