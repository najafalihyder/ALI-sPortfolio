import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/contexts/AuthContext";
import { Upload, BookOpen, Trophy, TrendingUp, Plus, Play } from "lucide-react";
import type { Document, Lesson, CompetitionParticipant } from "@shared/schema";

function DashboardContent() {
  const { user } = useAuth();

  const { data: documents, isLoading: docsLoading } = useQuery<Document[]>({
    queryKey: ["/api/documents", user?.uid],
  });

  const { data: lessons, isLoading: lessonsLoading } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons/user", user?.uid],
  });

  const { data: competitions, isLoading: competitionsLoading } = useQuery<CompetitionParticipant[]>({
    queryKey: ["/api/competitions/user", user?.uid],
  });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold font-brand mb-2">
            Welcome back, {user?.displayName || "Learner"}!
          </h1>
          <p className="text-lg text-muted-foreground">
            Ready to continue your learning journey?
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Link href="/upload">
            <Card className="hover-elevate cursor-pointer">
              <CardContent className="p-6 flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Upload className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Upload Document</h3>
                  <p className="text-sm text-muted-foreground">Start a new lesson</p>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Card>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-chart-3/10 flex items-center justify-center">
                <TrendingUp className="h-6 w-6 text-chart-3" />
              </div>
              <div>
                <h3 className="font-semibold">{lessons?.length || 0}</h3>
                <p className="text-sm text-muted-foreground">Lessons Completed</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-chart-2/10 flex items-center justify-center">
                <Trophy className="h-6 w-6 text-chart-2" />
              </div>
              <div>
                <h3 className="font-semibold">{competitions?.length || 0}</h3>
                <p className="text-sm text-muted-foreground">Active Competitions</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Lessons */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold font-brand">Recent Lessons</h2>
            <Link href="/upload">
              <Button variant="outline" className="gap-2" data-testid="button-new-lesson">
                <Plus className="h-4 w-4" />
                New Lesson
              </Button>
            </Link>
          </div>

          {lessonsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => (
                <Card key={i}>
                  <CardHeader>
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-10 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : lessons && lessons.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {lessons.slice(0, 6).map((lesson) => (
                <Card key={lesson.id} className="hover-elevate">
                  <CardHeader>
                    <CardTitle className="text-lg line-clamp-2">{lesson.title}</CardTitle>
                    <CardDescription>{lesson.duration} min lesson</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Link href={`/lesson/${lesson.id}`}>
                      <Button className="w-full gap-2" data-testid={`button-lesson-${lesson.id}`}>
                        <Play className="h-4 w-4" />
                        Start Lesson
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No lessons yet</h3>
                <p className="text-muted-foreground mb-4">
                  Upload your first document to start learning with AI
                </p>
                <Link href="/upload">
                  <Button data-testid="button-upload-first">
                    <Upload className="mr-2 h-4 w-4" />
                    Upload Document
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </div>

        {/* My Documents */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold font-brand">My Documents</h2>
          </div>

          {docsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => (
                <Card key={i}>
                  <CardHeader>
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2" />
                  </CardHeader>
                </Card>
              ))}
            </div>
          ) : documents && documents.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {documents.map((doc) => (
                <Card key={doc.id} className="hover-elevate">
                  <CardHeader>
                    <CardTitle className="text-lg line-clamp-2">{doc.title}</CardTitle>
                    <CardDescription className="flex items-center gap-2">
                      <span className="capitalize">{doc.type}</span>
                      <span>•</span>
                      <span>{new Date(doc.uploadedAt).toLocaleDateString()}</span>
                    </CardDescription>
                  </CardHeader>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No documents uploaded</h3>
                <p className="text-muted-foreground">
                  Upload PDFs or add URLs to create your first lesson
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  return (
    <ProtectedRoute>
      <DashboardContent />
    </ProtectedRoute>
  );
}
