import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/contexts/AuthContext";
import { Trophy, Users, Calendar, Medal, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Competition, CompetitionParticipant } from "@shared/schema";

function CompetitionsContent() {
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: competitions, isLoading } = useQuery<Competition[]>({
    queryKey: ["/api/competitions/active"],
  });

  const { data: myCompetitions } = useQuery<CompetitionParticipant[]>({
    queryKey: ["/api/competitions/user", user?.uid],
  });

  const joinMutation = useMutation({
    mutationFn: async (competitionId: string) => {
      return await apiRequest("POST", "/api/competitions/join", {
        competitionId,
        userId: user?.uid,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/competitions/active"] });
      queryClient.invalidateQueries({ queryKey: ["/api/competitions/user"] });
      toast({
        title: "Joined competition!",
        description: "Good luck with your learning challenge!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to join competition. Please try again.",
        variant: "destructive",
      });
    },
  });

  const isJoined = (competitionId: string) => {
    return myCompetitions?.some((p) => p.competitionId === competitionId);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold font-brand mb-2">Learning Competitions</h1>
          <p className="text-lg text-muted-foreground">
            Join challenges, compete with other learners, and climb the leaderboard
          </p>
        </div>

        {/* Active Competitions */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold font-brand mb-6">Active Challenges</h2>
          
          {isLoading ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {[1, 2].map((i) => (
                <Card key={i}>
                  <CardHeader>
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2" />
                  </CardHeader>
                  <CardContent>
                    <Skeleton className="h-20 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : competitions && competitions.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {competitions.map((comp) => {
                const joined = isJoined(comp.id);
                const daysLeft = Math.ceil(
                  (new Date(comp.endDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
                );

                return (
                  <Card key={comp.id} className="hover-elevate">
                    <CardHeader>
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <CardTitle className="text-xl mb-2">{comp.title}</CardTitle>
                          <CardDescription>{comp.description}</CardDescription>
                        </div>
                        <Badge
                          variant={comp.status === "active" ? "default" : "secondary"}
                          className="capitalize"
                        >
                          {comp.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <span>{daysLeft} days left</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-muted-foreground" />
                          <span>Challenge Topic: {comp.topic}</span>
                        </div>
                      </div>

                      {joined ? (
                        <div className="flex items-center gap-2 p-3 bg-primary/10 rounded-lg">
                          <Trophy className="h-5 w-5 text-primary" />
                          <span className="font-medium text-sm">You're participating!</span>
                        </div>
                      ) : (
                        <Button
                          className="w-full"
                          onClick={() => joinMutation.mutate(comp.id)}
                          disabled={joinMutation.isPending}
                          data-testid={`button-join-${comp.id}`}
                        >
                          {joinMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                          Join Challenge
                        </Button>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Trophy className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-semibold mb-2">No active competitions</h3>
                <p className="text-muted-foreground">
                  Check back soon for new learning challenges!
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* My Competitions */}
        {myCompetitions && myCompetitions.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold font-brand mb-6">My Competitions</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {myCompetitions.map((participation) => (
                <Card key={participation.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">Participating</Badge>
                      {participation.rank && (
                        <div className="flex items-center gap-1 text-primary">
                          <Medal className="h-4 w-4" />
                          <span className="font-semibold">#{participation.rank}</span>
                        </div>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center">
                      <div className="text-3xl font-bold mb-1">{participation.score}</div>
                      <div className="text-sm text-muted-foreground">points</div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function Competitions() {
  return (
    <ProtectedRoute>
      <CompetitionsContent />
    </ProtectedRoute>
  );
}
